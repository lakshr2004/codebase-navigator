const Record = require("../models/Record");

const handleControllerError = (error, res) => {
  if (error.name === "ValidationError") {
    const message = Object.values(error.errors).map(val => val.message).join(", ");
    return res.status(400).json({ message });
  }
  if (error.code === 11000) {
    return res.status(400).json({ message: "Duplicate field value entered" });
  }
  if (error.name === "CastError") {
    return res.status(404).json({ message: `Resource not found (invalid ID: ${error.value})` });
  }
  return res.status(500).json({
    message: "Server error",
    error: error.message,
  });
};

const createRecord = async (req, res) => {
  try {
    const { amount, type, category, date, note } = req.body;

    if (!amount || !type || !category) {
      return res.status(400).json({
        message: "Amount, type and category are required",
      });
    }

    const record = await Record.create({
      user: req.user._id,
      amount,
      type,
      category,
      date,
      note,
    });

    res.status(201).json({
      message: "Record created successfully",
      record,
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

const getRecords = async (req, res) => {
  try {
    const { page, limit, type, category, search, startDate, endDate } = req.query;

    // Base query scoping by role
    const query = req.user.role === "admin" ? {} : { user: req.user._id };

    // Apply type filter
    if (type && type !== "all") {
      query.type = type;
    }

    // Apply category filter
    if (category) {
      query.category = { $regex: category, $options: "i" };
    }

    // Apply text search on notes
    if (search) {
      query.note = { $regex: search, $options: "i" };
    }

    // Apply date range filter
    if (startDate || endDate) {
      query.date = {};
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        query.date.$lte = end;
      }
    }

    // Pagination setup
    const pageNum = parseInt(page) || 1;
    const limitNum = parseInt(limit) || 10;
    const skipNum = (pageNum - 1) * limitNum;

    // Query DB for count and data
    const total = await Record.countDocuments(query);
    const records = await Record.find(query)
      .sort({ date: -1 })
      .skip(skipNum)
      .limit(limitNum);

    res.status(200).json({
      total,
      page: pageNum,
      pages: Math.ceil(total / limitNum),
      limit: limitNum,
      records,
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

const updateRecord = async (req, res) => {
  try {
    const record = await Record.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    if (req.user.role !== "admin" && record.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const updatedRecord = await Record.findByIdAndUpdate(
      req.params.id,
      req.body,
      { returnDocument: 'after' }
    );

    res.status(200).json({
      message: "Record updated successfully",
      record: updatedRecord,
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

const deleteRecord = async (req, res) => {
  try {
    const record = await Record.findById(req.params.id);

    if (!record) {
      return res.status(404).json({ message: "Record not found" });
    }

    if (req.user.role !== "admin" && record.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await record.deleteOne();

    res.status(200).json({
      message: "Record deleted successfully",
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

const getDashboard = async (req, res) => {
  try {
    const query = req.user.role === "admin" ? {} : { user: req.user._id };
    const records = await Record.find(query);

    let totalIncome = 0;
    let totalExpense = 0;

    records.forEach((record) => {
      if (record.type === "income") {
        totalIncome += record.amount;
      } else if (record.type === "expense") {
        totalExpense += record.amount;
      }
    });

    const balance = totalIncome - totalExpense;

    res.status(200).json({
      totalIncome,
      totalExpense,
      balance,
    });
  } catch (error) {
    handleControllerError(error, res);
  }
};

module.exports = {
  createRecord,
  getRecords,
  updateRecord,
  deleteRecord,
  getDashboard,
};