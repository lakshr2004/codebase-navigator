import React from "react";
import { Link } from "react-router-dom";
import { ShieldAlert } from "lucide-react";

const Unauthorized = () => {
  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh", padding: "1rem", backgroundColor: "var(--bg-primary)" }}>
      <div className="card-panel" style={{ width: "100%", maxWidth: "440px", textAlign: "center", display: "flex", flexDirection: "column", gap: "1.25rem", padding: "2rem", backgroundColor: "#FFFFFF" }}>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <ShieldAlert size={48} style={{ color: "var(--accent-expense)" }} />
        </div>
        <div>
          <h2>Access Denied</h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", marginTop: "0.5rem" }}>
            You do not have the required administrative permissions to access this page.
          </p>
        </div>

        <Link to="/dashboard" className="btn btn-primary" style={{ textDecoration: "none", marginTop: "0.5rem" }}>
          Back to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default Unauthorized;
