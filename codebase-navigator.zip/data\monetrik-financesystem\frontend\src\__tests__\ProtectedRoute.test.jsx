import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { Navigate } from "react-router-dom";
import ProtectedRoute from "../components/ProtectedRoute";
import "@testing-library/jest-dom";

// Mock useAuth
const mockUseAuth = vi.fn();
vi.mock("../hooks/useAuth", () => ({
  useAuth: () => mockUseAuth(),
}));

// Mock Navigate
vi.mock("react-router-dom", () => ({
  Navigate: vi.fn(({ to }) => <div data-testid="navigate" data-to={to} />),
}));

describe("ProtectedRoute Component Tests", () => {
  beforeEach(() => {
    mockUseAuth.mockReset();
    vi.mocked(Navigate).mockClear();
  });

  it("renders spinner when loading is true", () => {
    mockUseAuth.mockReturnValue({
      user: null,
      loading: true,
      isAuthenticated: false,
    });

    render(
      <ProtectedRoute>
        <div data-testid="protected-content">Content</div>
      </ProtectedRoute>
    );

    expect(screen.queryByTestId("protected-content")).not.toBeInTheDocument();
    expect(screen.queryByTestId("navigate")).not.toBeInTheDocument();
  });

  it("redirects to login when user is not authenticated", () => {
    mockUseAuth.mockReturnValue({
      user: null,
      loading: false,
      isAuthenticated: false,
    });

    render(
      <ProtectedRoute>
        <div data-testid="protected-content">Content</div>
      </ProtectedRoute>
    );

    expect(screen.queryByTestId("protected-content")).not.toBeInTheDocument();
    const navigateEl = screen.getByTestId("navigate");
    expect(navigateEl).toBeInTheDocument();
    expect(navigateEl.getAttribute("data-to")).toBe("/login");
  });

  it("redirects to unauthorized when role is not allowed", () => {
    mockUseAuth.mockReturnValue({
      user: { role: "viewer" },
      loading: false,
      isAuthenticated: true,
    });

    render(
      <ProtectedRoute allowedRoles={["admin", "analyst"]}>
        <div data-testid="protected-content">Content</div>
      </ProtectedRoute>
    );

    expect(screen.queryByTestId("protected-content")).not.toBeInTheDocument();
    const navigateEl = screen.getByTestId("navigate");
    expect(navigateEl).toBeInTheDocument();
    expect(navigateEl.getAttribute("data-to")).toBe("/unauthorized");
  });

  it("renders children when authenticated and role is allowed", () => {
    mockUseAuth.mockReturnValue({
      user: { role: "admin" },
      loading: false,
      isAuthenticated: true,
    });

    render(
      <ProtectedRoute allowedRoles={["admin"]}>
        <div data-testid="protected-content">Content</div>
      </ProtectedRoute>
    );

    expect(screen.getByTestId("protected-content")).toBeInTheDocument();
    expect(screen.queryByTestId("navigate")).not.toBeInTheDocument();
  });
});
