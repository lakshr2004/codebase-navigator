const request = require("supertest");
const mongoose = require("mongoose");
const app = require("../app");
const User = require("../models/User");
const Record = require("../models/Record");
const RefreshToken = require("../models/RefreshToken");

const TEST_MONGO_URI = "mongodb://localhost:27017/financeDB_test";

beforeAll(async () => {
  // Override MONGO_URI for testing
  process.env.MONGO_URI = TEST_MONGO_URI;
  process.env.JWT_SECRET = "testsecret123";
  
  if (mongoose.connection.readyState === 0) {
    await mongoose.connect(TEST_MONGO_URI);
  }
});

beforeEach(async () => {
  // Clear database before each test
  await User.deleteMany({});
  await Record.deleteMany({});
  await RefreshToken.deleteMany({});
});

afterAll(async () => {
  // Close DB connection after all tests
  await mongoose.connection.close();
});

describe("Authentication & RBAC Endpoint Tests", () => {
  it("should fail to access protected routes without token", async () => {
    const res = await request(app).get("/api/records");
    expect(res.status).toBe(401);
    expect(res.body.message).toMatch(/not authorized/i);
  });

  it("should register a user with default role 'viewer'", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({
        name: "Viewer User",
        email: "viewer@test.com",
        password: "password123",
        role: "admin", // attempt to escalate role
      });

    expect(res.status).toBe(201);
    expect(res.body.user.role).toBe("viewer"); // escalations are ignored
  });

  it("should fail to register user with invalid email format", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({
        name: "Test User",
        email: "invalidemail@",
        password: "password123",
      });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/valid email/i);
  });

  it("should fail to register user with short password", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({
        name: "Test User",
        email: "test@test.com",
        password: "123",
      });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/at least 6 characters/i);
  });

  it("should log in a user and set refresh token cookie", async () => {
    // 1. Create a user
    await request(app)
      .post("/api/auth/register")
      .send({
        name: "Viewer User",
        email: "viewer@test.com",
        password: "password123",
      });

    // 2. Login
    const res = await request(app)
      .post("/api/auth/login")
      .send({
        email: "viewer@test.com",
        password: "password123",
      });

    expect(res.status).toBe(200);
    expect(res.body.token).toBeDefined();
    
    // Check cookie
    const cookies = res.headers["set-cookie"];
    expect(cookies).toBeDefined();
    const hasRefreshCookie = cookies.some((c) => c.includes("refreshToken="));
    expect(hasRefreshCookie).toBe(true);
  });

  it("should fail to login with incorrect password", async () => {
    await request(app)
      .post("/api/auth/register")
      .send({
        name: "Viewer User",
        email: "viewer@test.com",
        password: "password123",
      });

    const res = await request(app)
      .post("/api/auth/login")
      .send({
        email: "viewer@test.com",
        password: "wrongpassword",
      });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/invalid credentials/i);
  });

  it("should fail to login with missing fields", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({
        email: "",
        password: "",
      });
    expect(res.status).toBe(400);
    expect(res.body.message).toMatch(/required/i);
  });

  it("should refresh token and rotate refresh token", async () => {
    await request(app)
      .post("/api/auth/register")
      .send({
        name: "Viewer User",
        email: "viewer@test.com",
        password: "password123",
      });

    const loginRes = await request(app)
      .post("/api/auth/login")
      .send({
        email: "viewer@test.com",
        password: "password123",
      });

    const cookies = loginRes.headers["set-cookie"];
    const refreshCookie = cookies.find((c) => c.includes("refreshToken="));
    const tokenVal = refreshCookie.split(";")[0].split("=")[1];

    // Wait 1.1s to ensure JWT iat changes for rotation
    await new Promise((resolve) => setTimeout(resolve, 1100));

    const refreshRes = await request(app)
      .post("/api/auth/refresh")
      .set("Cookie", `refreshToken=${tokenVal}`);

    expect(refreshRes.status).toBe(200);
    expect(refreshRes.body.token).toBeDefined();

    // The old refresh token should be rotated/invalidated now
    const secondRefreshRes = await request(app)
      .post("/api/auth/refresh")
      .set("Cookie", `refreshToken=${tokenVal}`);
    
    expect(secondRefreshRes.status).toBe(403); // Token reuse detected
  });

  it("should allow admin to update user role, but deny analyst", async () => {
    const adminUser = await User.create({
      name: "Admin User",
      email: "admin@test.com",
      password: "hashedpassword",
      role: "admin",
    });

    const analystUser = await User.create({
      name: "Analyst User",
      email: "analyst@test.com",
      password: "hashedpassword",
      role: "analyst",
    });

    const viewerUser = await User.create({
      name: "Viewer User",
      email: "viewer@test.com",
      password: "hashedpassword",
      role: "viewer",
    });

    const jwt = require("jsonwebtoken");
    const adminToken = jwt.sign(
      { id: adminUser._id, role: adminUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    const analystToken = jwt.sign(
      { id: analystUser._id, role: analystUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    // 1. Analyst attempts to change viewer's role (deny)
    const analystRes = await request(app)
      .put(`/api/auth/users/${viewerUser._id}/role`)
      .set("Authorization", `Bearer ${analystToken}`)
      .send({ role: "analyst" });
    expect(analystRes.status).toBe(403);

    // 2. Admin attempts to change to invalid role (deny)
    const adminInvalidRes = await request(app)
      .put(`/api/auth/users/${viewerUser._id}/role`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ role: "invalid_role" });
    expect(adminInvalidRes.status).toBe(400);

    // 3. Admin updates role to analyst (success)
    const adminSuccessRes = await request(app)
      .put(`/api/auth/users/${viewerUser._id}/role`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ role: "analyst" });
    expect(adminSuccessRes.status).toBe(200);
    expect(adminSuccessRes.body.user.role).toBe("analyst");
  });

  it("should enforce route permissions for protected routes", async () => {
    const adminUser = await User.create({
      name: "Admin User",
      email: "admin@test.com",
      password: "hashedpassword",
      role: "admin",
    });

    const viewerUser = await User.create({
      name: "Viewer User",
      email: "viewer@test.com",
      password: "hashedpassword",
      role: "viewer",
    });

    const jwt = require("jsonwebtoken");
    const adminToken = jwt.sign(
      { id: adminUser._id, role: adminUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    const viewerToken = jwt.sign(
      { id: viewerUser._id, role: viewerUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    // /api/admin
    const adminRes1 = await request(app).get("/api/admin").set("Authorization", `Bearer ${adminToken}`);
    expect(adminRes1.status).toBe(200);

    const adminRes2 = await request(app).get("/api/admin").set("Authorization", `Bearer ${viewerToken}`);
    expect(adminRes2.status).toBe(403);

    // /api/analysis
    const analysisRes1 = await request(app).get("/api/analysis").set("Authorization", `Bearer ${adminToken}`);
    expect(analysisRes1.status).toBe(200);

    const analysisRes2 = await request(app).get("/api/analysis").set("Authorization", `Bearer ${viewerToken}`);
    expect(analysisRes2.status).toBe(403);
  });

  it("should fail to create record with negative amount or empty category", async () => {
    const adminUser = await User.create({
      name: "Admin User",
      email: "admin@test.com",
      password: "hashedpassword",
      role: "admin",
    });
    const jwt = require("jsonwebtoken");
    const adminToken = jwt.sign(
      { id: adminUser._id, role: adminUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    const resNegative = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ amount: -50, type: "expense", category: "Food" });
    expect(resNegative.status).toBe(400);
    expect(resNegative.body.message).toMatch(/positive/i);

    const resEmpty = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({ amount: 100, type: "expense", category: "" });
    expect(resEmpty.status).toBe(400);
    expect(resEmpty.body.message).toMatch(/required/i);
  });

  it("should enforce RBAC for record actions", async () => {
    // 1. Create an admin and a viewer user in DB directly
    const adminUser = await User.create({
      name: "Admin User",
      email: "admin@test.com",
      password: "hashedpassword", // standard placeholder
      role: "admin",
    });

    const viewerUser = await User.create({
      name: "Viewer User",
      email: "viewer@test.com",
      password: "hashedpassword",
      role: "viewer",
    });

    // Mock logging in and getting tokens
    const jwt = require("jsonwebtoken");
    const adminToken = jwt.sign(
      { id: adminUser._id, role: adminUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );
    const viewerToken = jwt.sign(
      { id: viewerUser._id, role: viewerUser.role, type: "access" },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    );

    // 2. Viewer attempts to create a record (should fail)
    const createResViewer = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${viewerToken}`)
      .send({
        amount: 100,
        type: "expense",
        category: "Food",
      });
    expect(createResViewer.status).toBe(403); // Forbidden

    // 3. Admin creates a record (should succeed)
    const createResAdmin = await request(app)
      .post("/api/records")
      .set("Authorization", `Bearer ${adminToken}`)
      .send({
        amount: 500,
        type: "income",
        category: "Dividends",
        note: "Starchart dividends",
      });
    expect(createResAdmin.status).toBe(201);
    const recordId = createResAdmin.body.record._id;

    // 4. Admin updates the record (should succeed)
    const updateRes = await request(app)
      .put(`/api/records/${recordId}`)
      .set("Authorization", `Bearer ${adminToken}`)
      .send({
        amount: 600,
      });
    expect(updateRes.status).toBe(200);
    expect(updateRes.body.record.amount).toBe(600);

    // 5. Admin deletes the record (should succeed)
    const deleteRes = await request(app)
      .delete(`/api/records/${recordId}`)
      .set("Authorization", `Bearer ${adminToken}`);
    expect(deleteRes.status).toBe(200);
  });
});
