import api from "./api";

/**
 * Extract actual error message from Axios error and throw it
 * @param {Error} error 
 */
const handleError = (error) => {
  const message = error.response?.data?.message || error.message || "An error occurred";
  throw new Error(message);
};

/**
 * Create a new financial record
 * @param {object} recordData - { amount, type, category, date, note }
 * @returns {Promise<object>} Created record details
 */
export const createRecord = async ({ amount, type, category, date, note }) => {
  try {
    const response = await api.post("/records", { amount, type, category, date, note });
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Fetch financial records with optional search, pagination, and filter parameters
 * @param {object} params - { page, limit, type, category, search, startDate, endDate }
 * @returns {Promise<object>} Returns { total, page, pages, limit, records: [] }
 */
export const getRecords = async (params = {}) => {
  try {
    const response = await api.get("/records", { params });
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Fetch the dashboard financial summary
 * @returns {Promise<object>} Returns { totalIncome, totalExpense, balance }
 */
export const getDashboardSummary = async () => {
  try {
    const response = await api.get("/records/summary");
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Update an existing financial record (Admin only for any, or owner depending on check)
 * @param {string} id
 * @param {object} updates - Fields to update
 * @returns {Promise<object>} Updated record details
 */
export const updateRecord = async (id, updates) => {
  try {
    const response = await api.put(`/records/${id}`, updates);
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Delete a financial record (Admin only)
 * @param {string} id
 * @returns {Promise<object>} Success message response
 */
export const deleteRecord = async (id) => {
  try {
    const response = await api.delete(`/records/${id}`);
    return response.data;
  } catch (error) {
    handleError(error);
  }
};
