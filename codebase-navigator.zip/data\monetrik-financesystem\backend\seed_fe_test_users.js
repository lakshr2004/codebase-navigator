const mongoose = require("mongoose");
const User = require("./models/User");
const Record = require("./models/Record");
const bcrypt = require("bcrypt");

const MONGO_URI = "mongodb://localhost:27017/financeDB";

const seedUsersAndRecords = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log("Connected to MongoDB for frontend test seeding...");

    // Clear old test records
    await Record.deleteMany({});
    console.log("Cleared all records from database.");

    const passwordHash = await bcrypt.hash("password123", 10);

    const testUsers = [
      {
        name: "FE Admin",
        email: "fe_admin@test.com",
        password: passwordHash,
        role: "admin",
        status: "active"
      },
      {
        name: "FE Analyst",
        email: "fe_analyst@test.com",
        password: passwordHash,
        role: "analyst",
        status: "active"
      },
      {
        name: "FE Viewer",
        email: "fe_viewer@test.com",
        password: passwordHash,
        role: "viewer",
        status: "active"
      }
    ];

    const usersMap = {};
    for (const u of testUsers) {
      await User.findOneAndDelete({ email: u.email });
      const createdUser = await User.create(u);
      usersMap[u.role] = createdUser;
      console.log(`Seeded user: ${u.email} with role: ${u.role}`);
    }

    // 1. Seed admin record (Dividends)
    const adminRecord = await Record.create({
      user: usersMap["admin"]._id,
      amount: 3000,
      type: "income",
      category: "Dividends",
      note: "Admin dividends",
      date: new Date()
    });
    console.log(`Seeded Admin record: ${adminRecord.category}`);

    // 2. Seed analyst record (Salary)
    const analystRecord = await Record.create({
      user: usersMap["analyst"]._id,
      amount: 1500,
      type: "income",
      category: "Salary",
      note: "Analyst salary",
      date: new Date()
    });
    console.log(`Seeded Analyst record: ${analystRecord.category}`);

    // 3. Seed viewer record (Books)
    const viewerRecord = await Record.create({
      user: usersMap["viewer"]._id,
      amount: 200,
      type: "expense",
      category: "Books",
      note: "Viewer textbook",
      date: new Date()
    });
    console.log(`Seeded Viewer record: ${viewerRecord.category}`);

    await mongoose.disconnect();
    console.log("Seeding complete. Mongoose disconnected.");
  } catch (err) {
    console.error("Seeding failed:", err.message);
    process.exit(1);
  }
};

seedUsersAndRecords();
