import React, { useState, useEffect } from "react";
import { getRecords } from "../services/records";
import { Calendar, BarChart3, TrendingUp, TrendingDown, ArrowUpRight, ArrowDownRight, Activity } from "lucide-react";

const Analysis = () => {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filterRange, setFilterRange] = useState("all"); // "month" | "3months" | "all"

  // Fetch all transactions
  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");
      const response = await getRecords();
      setRecords(response.records || []);
    } catch (err) {
      setError(err.message || "Failed to load records for analysis.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Format currency helper (INR)
  const formatCurrency = (val) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR"
    }).format(val);
  };

  // Client-side date filters
  const filterRecordsByRange = (items) => {
    const now = new Date();
    return items.filter((rec) => {
      const recDate = new Date(rec.date);
      if (filterRange === "month") {
        return (
          recDate.getMonth() === now.getMonth() &&
          recDate.getFullYear() === now.getFullYear()
        );
      } else if (filterRange === "3months") {
        const threeMonthsAgo = new Date();
        threeMonthsAgo.setMonth(now.getMonth() - 3);
        return recDate >= threeMonthsAgo;
      }
      return true; // "all"
    });
  };

  const filteredRecords = filterRecordsByRange(records);

  // Calculate metrics for filtered set
  let incomeTotal = 0;
  let expenseTotal = 0;
  const categoryExpenses = {};

  filteredRecords.forEach((rec) => {
    if (rec.type === "income") {
      incomeTotal += rec.amount;
    } else if (rec.type === "expense") {
      expenseTotal += rec.amount;
      // Group expenses by category
      categoryExpenses[rec.category] = (categoryExpenses[rec.category] || 0) + rec.amount;
    }
  });

  const activeBalance = incomeTotal - expenseTotal;

  // Convert category expenses to sorted array
  const sortedCategories = Object.entries(categoryExpenses)
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);

  const maxExpenseCategoryAmount = sortedCategories.length > 0 ? sortedCategories[0].amount : 1;

  // Calculate ratio metrics
  const totalFlow = incomeTotal + expenseTotal;
  const incomePercent = totalFlow > 0 ? Math.round((incomeTotal / totalFlow) * 100) : 0;
  const expensePercent = totalFlow > 0 ? Math.round((expenseTotal / totalFlow) * 100) : 0;

  if (loading) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "0.5rem", alignItems: "center", justifyContent: "center", minHeight: "50vh" }}>
        <div style={{
          width: "24px",
          height: "24px",
          border: "2px solid var(--border-color)",
          borderTopColor: "var(--primary)",
          borderRadius: "50%",
          animation: "spin 1s linear infinite"
        }} />
        <span style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>Analysing transaction logs...</span>
        <style dangerouslySetInnerHTML={{__html: `@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="card-panel" style={{ textAlign: "center", padding: "3rem" }}>
        <p style={{ color: "var(--accent-expense)", fontWeight: "600" }}>{error}</p>
        <button onClick={fetchData} className="btn btn-primary" style={{ marginTop: "1rem" }}>Retry</button>
      </div>
    );
  }

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: "2rem", width: "100%" }}>
      
      {/* Header section with filter buttons */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
        <div>
          <h2>Analytics & Trends</h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Visual breakdowns of your financial allocations</p>
        </div>

        {/* Filter pills */}
        <div style={{
          display: "flex",
          backgroundColor: "#E5E5E2",
          padding: "0.2rem",
          borderRadius: "var(--radius-sm)",
          border: "1px solid var(--border-color)"
        }} id="time-filter-tabs">
          <button
            onClick={() => setFilterRange("month")}
            style={{
              padding: "0.4rem 0.85rem",
              border: "none",
              borderRadius: "3px",
              backgroundColor: filterRange === "month" ? "var(--bg-secondary)" : "transparent",
              color: filterRange === "month" ? "var(--text-primary)" : "var(--text-secondary)",
              fontWeight: filterRange === "month" ? "600" : "500",
              fontSize: "0.8rem",
              cursor: "pointer",
              transition: "all var(--transition-fast)"
            }}
            className="filter-pill-month"
          >
            This Month
          </button>
          <button
            onClick={() => setFilterRange("3months")}
            style={{
              padding: "0.4rem 0.85rem",
              border: "none",
              borderRadius: "3px",
              backgroundColor: filterRange === "3months" ? "var(--bg-secondary)" : "transparent",
              color: filterRange === "3months" ? "var(--text-primary)" : "var(--text-secondary)",
              fontWeight: filterRange === "3months" ? "600" : "500",
              fontSize: "0.8rem",
              cursor: "pointer",
              transition: "all var(--transition-fast)"
            }}
            className="filter-pill-3months"
          >
            Last 3 Months
          </button>
          <button
            onClick={() => setFilterRange("all")}
            style={{
              padding: "0.4rem 0.85rem",
              border: "none",
              borderRadius: "3px",
              backgroundColor: filterRange === "all" ? "var(--bg-secondary)" : "transparent",
              color: filterRange === "all" ? "var(--text-primary)" : "var(--text-secondary)",
              fontWeight: filterRange === "all" ? "600" : "500",
              fontSize: "0.8rem",
              cursor: "pointer",
              transition: "all var(--transition-fast)"
            }}
            className="filter-pill-all"
          >
            All Time
          </button>
        </div>
      </div>

      {/* Grid containing filtered cards summary */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
        gap: "1.25rem"
      }}>
        <div className="card-panel" style={{ padding: "1.25rem", display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <ArrowUpRight size={18} style={{ color: "var(--accent-income)" }} />
          <div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Range Income</div>
            <div style={{ fontSize: "1.15rem", fontWeight: "600", fontFamily: "var(--font-mono)" }}>{formatCurrency(incomeTotal)}</div>
          </div>
        </div>
        <div className="card-panel" style={{ padding: "1.25rem", display: "flex", gap: "0.75rem", alignItems: "center" }}>
          <ArrowDownRight size={18} style={{ color: "var(--accent-expense)" }} />
          <div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Range Expenses</div>
            <div style={{ fontSize: "1.15rem", fontWeight: "600", fontFamily: "var(--font-mono)" }}>{formatCurrency(expenseTotal)}</div>
          </div>
        </div>
        <div className="card-panel" style={{
          padding: "1.25rem",
          display: "flex",
          gap: "0.75rem",
          alignItems: "center",
          borderLeft: `3px solid ${activeBalance >= 0 ? "var(--accent-income)" : "var(--accent-expense)"}`
        }}>
          <Calendar size={18} style={{ color: activeBalance >= 0 ? "var(--accent-income)" : "var(--accent-expense)" }} />
          <div>
            <div style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Range Balance</div>
            <div style={{ fontSize: "1.15rem", fontWeight: "600", color: activeBalance >= 0 ? "var(--accent-income)" : "var(--accent-expense)", fontFamily: "var(--font-mono)" }}>
              {formatCurrency(activeBalance)}
            </div>
          </div>
        </div>
      </div>

      {filteredRecords.length === 0 ? (
        <div className="card-panel" style={{ textAlign: "center", padding: "4rem 2rem", display: "flex", flexDirection: "column", gap: "0.5rem", alignItems: "center" }}>
          <Activity size={32} style={{ color: "var(--text-tertiary)" }} />
          <h3 style={{ marginTop: "0.5rem" }}>No Transactions Found</h3>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>
            There are no logs matching the selected filter range.
          </p>
        </div>
      ) : (
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))",
          gap: "1.25rem"
        }}>
          {/* Category Spending Graph */}
          <div className="card-panel" style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <BarChart3 size={16} style={{ color: "var(--primary)" }} />
              <h3>Category-wise Spending</h3>
            </div>
            
            {sortedCategories.length === 0 ? (
              <div style={{ color: "var(--text-secondary)", textAlign: "center", padding: "2rem", fontSize: "0.9rem" }}>
                No expense logs recorded.
              </div>
            ) : (
              <div style={{ display: "flex", flexDirection: "column", gap: "1.1rem" }} id="category-chart">
                {sortedCategories.map(({ category, amount }) => {
                  const percent = Math.round((amount / maxExpenseCategoryAmount) * 100);
                  return (
                    <div key={category} style={{ display: "flex", flexDirection: "column", gap: "0.25rem" }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.85rem" }}>
                        <span style={{ fontWeight: "600" }}>{category}</span>
                        <span style={{ color: "var(--accent-expense)", fontWeight: "600", fontFamily: "var(--font-mono)" }}>{formatCurrency(amount)}</span>
                      </div>
                      
                      {/* CSS-based Bar Chart */}
                      <div style={{
                        width: "100%",
                        height: "8px",
                        backgroundColor: "#E5E5E2",
                        borderRadius: "4px",
                        overflow: "hidden"
                      }}>
                        <div style={{
                          width: `${percent}%`,
                          height: "100%",
                          backgroundColor: "var(--accent-expense)",
                          borderRadius: "4px"
                        }} className="chart-bar" />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Income vs Expense Split */}
          <div className="card-panel" style={{ display: "flex", flexDirection: "column", gap: "1.25rem", justifyContent: "space-between" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
              <BarChart3 size={16} style={{ color: "var(--primary)" }} />
              <h3>Income vs Expense Ratio</h3>
            </div>

            <div style={{
              display: "flex",
              flexDirection: "column",
              gap: "1.5rem",
              flex: "1",
              justifyContent: "center",
              padding: "0.5rem 0"
            }} id="ratio-chart">
              {/* Vertical Ratio Bars */}
              <div style={{
                display: "flex",
                justifyContent: "space-around",
                alignItems: "flex-end",
                height: "150px",
                backgroundColor: "var(--bg-primary)",
                borderRadius: "var(--radius-sm)",
                padding: "1rem",
                border: "1px solid var(--border-color)"
              }}>
                {/* Income Bar */}
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "0.35rem" }}>
                  <span style={{ color: "var(--accent-income)", fontWeight: "600", fontSize: "0.85rem" }}>{incomePercent}%</span>
                  <div style={{
                    width: "40px",
                    height: `${Math.max(incomePercent, 2)}%`,
                    maxHeight: "100px",
                    backgroundColor: "var(--accent-income)",
                    borderRadius: "2px 2px 0 0"
                  }} className="ratio-bar-income" />
                  <span style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Income</span>
                </div>

                {/* Expense Bar */}
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "0.35rem" }}>
                  <span style={{ color: "var(--accent-expense)", fontWeight: "600", fontSize: "0.85rem" }}>{expensePercent}%</span>
                  <div style={{
                    width: "40px",
                    height: `${Math.max(expensePercent, 2)}%`,
                    maxHeight: "100px",
                    backgroundColor: "var(--accent-expense)",
                    borderRadius: "2px 2px 0 0"
                  }} className="ratio-bar-expense" />
                  <span style={{ fontSize: "0.75rem", color: "var(--text-secondary)" }}>Expense</span>
                </div>
              </div>

              {/* Progress Split Bar */}
              <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.8rem", color: "var(--text-secondary)" }}>
                  <span>Income ({formatCurrency(incomeTotal)})</span>
                  <span>Expense ({formatCurrency(expenseTotal)})</span>
                </div>
                
                <div style={{
                  width: "100%",
                  height: "6px",
                  backgroundColor: "var(--accent-expense)",
                  borderRadius: "3px",
                  overflow: "hidden",
                  display: "flex"
                }}>
                  <div style={{
                    width: `${incomePercent}%`,
                    height: "100%",
                    backgroundColor: "var(--accent-income)"
                  }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Analysis;
