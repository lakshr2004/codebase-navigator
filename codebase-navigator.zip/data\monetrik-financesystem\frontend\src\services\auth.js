import api from "./api";

/**
 * Extract actual error message from Axios error and throw it
 * @param {Error} error 
 */
const handleError = (error) => {
  const message = error.response?.data?.message || error.message || "An error occurred";
  throw new Error(message);
};

/**
 * Register a new user (role ignored by backend, defaults to "viewer")
 * @param {string} name
 * @param {string} email
 * @param {string} password
 * @returns {Promise<object>} Registered user details
 */
export const register = async (name, email, password) => {
  try {
    const response = await api.post("/auth/register", { name, email, password });
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Log in a user with email and password
 * @param {string} email
 * @param {string} password
 * @returns {Promise<object>} Object containing message, token, and user details
 */
export const login = async (email, password) => {
  try {
    const response = await api.post("/auth/login", { email, password });
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Update a user's role (Admin Only)
 * @param {string} userId
 * @param {string} newRole - "admin" | "analyst" | "viewer"
 * @returns {Promise<object>} Updated user details
 */
export const updateUserRole = async (userId, newRole) => {
  try {
    const response = await api.put(`/auth/users/${userId}/role`, { role: newRole });
    return response.data;
  } catch (error) {
    handleError(error);
  }
};

/**
 * Log out user by clearing credentials from localStorage
 */
export const logout = async () => {
  try {
    await api.post("/auth/logout");
  } catch (error) {
    console.error("Logout request failed:", error.message);
  } finally {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
  }
};
