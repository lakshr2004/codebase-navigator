import React, { useState } from "react";
import { useAuth } from "../hooks/useAuth";
import { Link } from "react-router-dom";

const Register = () => {
  const { register } = useAuth();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const validateForm = () => {
    if (!name || !email || !password) {
      setError("Please fill in all fields.");
      return false;
    }
    if (name.trim().length < 2) {
      setError("Name must be at least 2 characters long.");
      return false;
    }
    const emailRegex = /^\S+@\S+\.\S+$/;
    if (!emailRegex.test(email)) {
      setError("Please enter a valid email address.");
      return false;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters long.");
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess(false);

    if (!validateForm()) return;

    setLoading(true);
    const result = await register(name, email, password);
    setLoading(false);

    if (result.success) {
      setSuccess(true);
      setName("");
      setEmail("");
      setPassword("");
    } else {
      setError(result.error);
    }
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh", padding: "1rem", backgroundColor: "var(--bg-primary)" }}>
      <div className="card-panel" style={{ width: "100%", maxWidth: "400px", display: "flex", flexDirection: "column", gap: "1.25rem", padding: "2rem", backgroundColor: "#FFFFFF", boxShadow: "0 4px 15px rgba(0,0,0,0.02)" }}>
        <div style={{ textAlign: "center" }}>
          <h2>Create Account</h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.85rem", marginTop: "0.25rem" }}>Get started with Monetrik</p>
        </div>

        {error && (
          <div style={{
            padding: "0.65rem 0.85rem",
            backgroundColor: "var(--accent-expense-glow)",
            border: "1px solid rgba(178, 59, 59, 0.2)",
            borderRadius: "var(--radius-sm)",
            color: "var(--accent-expense)",
            fontSize: "0.85rem"
          }}>
            {error}
          </div>
        )}

        {success && (
          <div style={{
            padding: "1rem",
            backgroundColor: "var(--accent-income-glow)",
            border: "1px solid rgba(27, 122, 76, 0.2)",
            borderRadius: "var(--radius-sm)",
            color: "var(--accent-income)",
            fontSize: "0.9rem",
            textAlign: "center",
            display: "flex",
            flexDirection: "column",
            gap: "0.75rem"
          }}>
            <span>Registration successful.</span>
            <Link to="/login" className="btn btn-primary" style={{ padding: "0.4rem 0.85rem", fontSize: "0.8rem", textDecoration: "none", width: "100%" }}>
              Sign In
            </Link>
          </div>
        )}

        {!success && (
          <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.1rem" }}>
            <div>
              <label htmlFor="name">Full Name</label>
              <input
                type="text"
                id="name"
                placeholder="John Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div>
              <label htmlFor="email">Email Address</label>
              <input
                type="email"
                id="email"
                placeholder="name@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div>
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                placeholder="Min. 6 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="btn btn-primary"
              disabled={loading}
              style={{ width: "100%", marginTop: "0.5rem" }}
            >
              {loading ? "Registering..." : "Register"}
            </button>
          </form>
        )}

        <div style={{ textAlign: "center", fontSize: "0.85rem", color: "var(--text-secondary)" }}>
          Already have an account?{" "}
          <Link to="/login" style={{ fontWeight: "600" }}>
            Sign In instead
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
