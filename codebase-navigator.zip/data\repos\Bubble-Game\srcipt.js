var timer = 20;
var score = 0;
var hitNum = 0;


function increaseScore() {
    score += 10;
    document.querySelector("#getScore").textContent = score;
}

function decreaseScore() {
    score -= 10;
    document.querySelector("#getScore").textContent = score;
}

function getNewHit() {
    hitNum = Math.floor(Math.random() * 10);
    document.querySelector("#hitTimer").textContent = hitNum;
}

function makeBubble() {
    var clutter = "";
    for (var i = 1; i <= 76; i++) {
        var bEl = Math.floor(Math.random() * 10);
        clutter += `<div class="bubble">${bEl}</div>`;
    }
    document.querySelector("#pannel-bottom").innerHTML = clutter;
}

function runTimer() {
    var timerint = setInterval(function () {
        if (timer > 0) {
            timer--;
            document.querySelector("#Timer").textContent = timer;
        } else {
            document.querySelector("#pannel-bottom").innerHTML = `<h1>Game Over !!<br>Your Score: ${score}<br>Play again !!</h1>`;
            clearInterval(timerint);
        }
    }, 1000);
}

document.querySelector("#pannel-bottom").addEventListener("click", function (details) {
    var clickedNum = Number(details.target.textContent);
    if(clickedNum === hitNum){
        increaseScore();
        makeBubble();
        getNewHit();
    }else{
        decreaseScore();
        makeBubble();
        getNewHit();
    }
})

getNewHit();
runTimer();
makeBubble();


