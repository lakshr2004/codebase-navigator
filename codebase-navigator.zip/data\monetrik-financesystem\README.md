# Monetrik — Finance Data Processing & Access Control System

![Live Demo](https://img.shields.io/badge/demo-live-brightgreen) ![License](https://img.shields.io/badge/license-MIT-blue) ![Stack](https://img.shields.io/badge/stack-MERN-informational)

Monetrik is a secure, multi-role financial record management and analysis application. Built with a full-stack JavaScript architecture, it provides granular Role-Based Access Control (RBAC) to ensure strict data isolation and secure access. Monetrik is designed for teams and organizations that require tiered permissions (Admin, Analyst, and Viewer) to log, audit, and analyze income and expense streams.

### 🔗 [Live Demo](https://monetrik-finance-system.vercel.app/login)

Try it right now with the test accounts below — no setup needed.

| Role | Email | Password | Can do |
|---|---|---|---|
| **Admin** | `fe_admin@test.com` | `password123` | Full access — view/edit/delete any record, manage user roles, view analytics |
| **Analyst** | `fe_analyst@test.com` | `password123` | Create + view own records, view analytics (no edit/delete) |
| **Viewer** | `fe_viewer@test.com` | `password123` | Read-only access to own records (no create/edit/delete/analytics) |

> Note: the backend is on Render's free tier, so the first request after inactivity may take 20–30 seconds to wake up.

---

## Tech Stack

The application separates concerns by maintaining an independent Backend API and a client-side Single Page Application (SPA).

### Backend
*   **Core**: Node.js, Express.js
*   **Database**: MongoDB, Mongoose (ODM)
*   **Security & Auth**: JSON Web Tokens (JWT), bcrypt (password hashing)
*   **CORS & Utilities**: CORS, dotenv

### Frontend
*   **Core**: React 18, Vite (build tool & dev server)
*   **Routing**: React Router DOM v6
*   **HTTP Client**: Axios (configured with interceptors for token attachment)
*   **Styling**: Modern CSS System (CSS Custom Properties, responsive design, light-only institutional fintech theme featuring an off-white background, navy accents, and flat white cards)
*   **Icons**: Lucide React

---

## Key Features

*   **Role-Based Access Control (RBAC)**: Secure routes on both frontend (UI routing level) and backend (API endpoint controllers) protecting actions based on three user tiers: `admin`, `analyst`, and `viewer`.
*   **Data Isolation**: Viewers and Analysts can only view and manage their own financial entries, while Admins have global visibility over all records.
*   **JWT-Based Authentication**: Secure stateless authentication backed by encrypted HTTP headers, including automatic session hydration upon browser refresh.
*   **Real-Time Financial Dashboard**: Visual breakdowns showing total income, total expenses, and the current net balance updated instantly.
*   **Category-Wise Analytics**: Rich, client-side breakdown of spending patterns by category, accompanied by time-range filtering (Analysis view restricted to Admins and Analysts).
*   **Robust Security & Sanitized Errors**: Controller-level boundary checks preventing unauthorized updates, Mongoose validator error normalization, and clean HTTP response codes that do not leak server stack traces.

---

## Architecture

Monetrik follows a decoupled project structure dividing the codebase into frontend and backend subdirectories:

```text
Monetrik/
├── backend/
│   ├── config/             # Database connection configuration
│   ├── controllers/        # Business logic for auth and records
│   ├── middleware/         # Auth verification and RBAC middleware
│   ├── models/             # Mongoose schemas (User, Record)
│   ├── routes/             # Express API endpoints routing
│   ├── app.js              # Express app setup & route mounting
│   ├── server.js           # Server entry point
│   ├── .env.example        # Environment variable template
│   └── package.json        # Backend dependencies & scripts
├── docs/
│   └── screenshots/        # Verified application screenshots for documentation
├── frontend/
│   ├── public/             # Static public assets (icons, favicon)
│   ├── src/
│   │   ├── assets/         # App images and vector assets
│   │   ├── components/     # Reusable components (e.g., ProtectedRoute)
│   │   ├── context/        # React context (AuthContext)
│   │   ├── hooks/          # Custom hooks (useAuth)
│   │   ├── layouts/        # Layout wrappers (MainLayout, Navbar)
│   │   ├── pages/          # Page components (Dashboard, Analysis, etc.)
│   │   ├── services/       # API integration layers (Axios instances)
│   │   ├── App.jsx         # Main router and app layout configuration
│   │   └── index.css       # Core typography, tokens & styling system
│   ├── index.html          # HTML entrypoint
│   ├── vite.config.js      # Vite build & proxy settings
│   └── package.json        # Frontend dependencies & scripts
├── LICENSE                 # Project license file
└── README.md               # Root documentation
```

---

## RBAC Permission Matrix

| Capability / Action | Admin | Analyst | Viewer | Backend Enforcement | Frontend Enforcement |
| :--- | :---: | :---: | :---: | :--- | :--- |
| **View Own Records** | Yes | Yes | Yes | Scoped query via `user: req.user._id` | Filtered list view on Dashboard |
| **View All (Any) Records** | Yes | No | No | Unscoped query via `{}` in controller | Admin table view with creator details |
| **Create Records** | Yes | Yes | No | Endpoint restricted: `admin`, `analyst` | Add record form hidden for Viewers |
| **Edit Own Records** | Yes | No | No | Endpoint restricted: `admin` | Edit button hidden for non-admins |
| **Edit All (Any) Records** | Yes | No | No | Endpoint restricted: `admin` | Edit button hidden for non-admins |
| **Delete Own Records** | Yes | No | No | Endpoint restricted: `admin` | Delete button hidden for non-admins |
| **Delete All (Any) Records** | Yes | No | No | Endpoint restricted: `admin` | Delete button hidden for non-admins |
| **Access Analysis Page** | Yes | Yes | No | Inline route restricted: `admin`, `analyst` | Router route wrapper blocks `viewer` |
| **Update User Roles** | Yes | No | No | Endpoint restricted: `admin` | Admin-only dashboard actions |

---

## API Endpoints Reference

### Authentication & User Management
| Method | Endpoint | Allowed Roles | Description |
| :--- | :--- | :---: | :--- |
| `POST` | `/api/auth/register` | Public | Register a new user (defaults to `viewer` role) |
| `POST` | `/api/auth/login` | Public | Authenticate credentials and return JWT & user details |
| `PUT` | `/api/auth/users/:id/role` | `admin` | Update the role (admin, analyst, viewer) of a user |

### Financial Records
| Method | Endpoint | Allowed Roles | Description |
| :--- | :--- | :---: | :--- |
| `GET` | `/api/records` | Authenticated | Fetch financial records (scoped to user, or global if admin) |
| `POST` | `/api/records` | `admin`, `analyst` | Create a new financial record (amount, type, category, date, note) |
| `GET` | `/api/records/summary` | Authenticated | Retrieve summary metrics (total income, total expense, balance) |
| `PUT` | `/api/records/:id` | `admin` | Update fields of an existing financial record |
| `DELETE` | `/api/records/:id` | `admin` | Permanently delete a financial record |

---

## Setup Instructions

Ensure you have [Node.js](https://nodejs.org/) (v16+) and [MongoDB](https://www.mongodb.com/) installed and running on your local machine.

### 1. Clone the Repository
```bash
git clone https://github.com/lakshr2004/Monetrik-FinanceSystem.git
cd Monetrik-FinanceSystem
```

### 2. Backend Setup
1. Navigate into the backend directory:
   ```bash
   cd backend
   ```
2. Install the server dependencies:
   ```bash
   npm install
   ```
3. Configure the environment variables:
   Create a `.env` file in the `backend/` folder. You can copy the structure from `.env.example`:
   ```bash
   cp .env.example .env
   ```
   Modify `.env` to match your local setup:
   ```text
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/financeDB
   JWT_SECRET=your_jwt_secret_here
   FRONTEND_URL=http://localhost:5173
   ```
4. Start the backend development server:
   ```bash
   npm run dev
   ```
   The backend API will be running at: `http://localhost:5000`

### 3. Frontend Setup
1. Open a new terminal session and navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Install the client dependencies:
   ```bash
   npm install
   ```
3. Start the Vite development server:
   ```bash
   npm run dev
   ```
   The frontend app will be running at: `http://localhost:5173`

---

## Screenshots

Below are the layouts of the redesigned application.

### Login Screen
![Login Page Redesign](docs/screenshots/login_page_redesign.png)
*Modern login screen featuring secure credentials handling and instant redirects, utilizing a clean, light-only institutional fintech layout.*

### Main Dashboard
![Dashboard Page Redesign](docs/screenshots/dashboard_page_redesign.png)
*The main user dashboard featuring summary statistics (Income, Expense, and net Balance) and interactive transaction logs on flat white cards.*

### Category Analytics
![Analysis Page Redesign](docs/screenshots/analysis_page_redesign.png)
*Role-restricted analytics view displaying dynamic category breakdowns and transaction filters.*

---

## Testing & QA

The live deployment was put through a 32-case end-to-end test pass covering auth, RBAC enforcement, record CRUD validation, and security checks — **31/32 passed**, with 1 minor cosmetic issue found and logged.

**Covered:**
*   Role-based login for all three roles (Admin, Analyst, Viewer).
*   Auth edge cases: duplicate email, weak password, malformed email, wrong password, empty fields, missing-field validation.
*   RBAC boundary enforcement per role — verified viewers/analysts get a real `403 Forbidden` from the backend on restricted actions (not just a hidden button on the frontend).
*   Account-enumeration protection — login returns the same generic "Invalid credentials" message whether the email doesn't exist or the password is wrong.
*   Password fields confirmed stripped from every auth response payload.
*   Record validation: negative amounts, zero amounts, missing fields, and an XSS payload (`<script>alert(1)</script>`) in the notes field — confirmed stored as plain text and safely escaped on render, not executed.
*   Dashboard summary totals cross-checked against raw record data for accuracy.

**Known issue (open):**
*   Requesting a malformed/non-existent record ID returns Express's default HTML 404 page instead of a JSON error response. Cosmetic/API-consistency issue, not a security or data-integrity risk — on the list to fix.

---

## Future Improvements

*   Automated test suite (Jest/Supertest for backend, RTL for frontend) with CI on GitHub Actions.
*   Pagination and server-side search/filtering for the records list as data grows.
*   Refresh-token rotation instead of a single long-lived JWT.
*   CSV/PDF export for financial records and analytics.

---

## License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.
