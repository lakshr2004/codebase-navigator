import unittest
import os
import sys
import time
import subprocess
import requests

# Ensure project root is in the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

PORT = 8888
BASE_URL = f"http://localhost:{PORT}"

class TestCareerCopilotIntegration(unittest.TestCase):
    server_process = None

    @classmethod
    def setUpClass(cls):
        # Start the FastAPI server on a custom port
        print(f"\n--- Starting FastAPI Server on port {PORT} ---")
        env = os.environ.copy()
        env["PORT"] = str(PORT)
        
        # Start main.py in a background process using uvicorn module directly
        cls.server_process = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "main:app", "--port", str(PORT)],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        # Poll server until it is alive (up to 12 seconds)
        start_time = time.time()
        connected = False
        while time.time() - start_time < 12.0:
            try:
                response = requests.get(BASE_URL + "/", timeout=1.0)
                if response.status_code == 200:
                    connected = True
                    break
            except requests.exceptions.RequestException:
                pass
            time.sleep(0.5)
            
        if not connected:
            cls.tearDownClass()
            raise RuntimeError("FastAPI server failed to start on time.")
        print("--- FastAPI Server is up and running ---")

    @classmethod
    def tearDownClass(cls):
        if cls.server_process:
            print("\n--- Stopping FastAPI Server ---")
            cls.server_process.terminate()
            cls.server_process.wait()
            print("--- FastAPI Server stopped ---")

    def test_sample_a_software_engineer(self):
        print("\n--- Running Sample A (Software & ML Engineer) ---")
        
        resume_text = (
            "LAKSH RAJ\n"
            "Full Stack & Machine Learning Engineer\n"
            "aec.it.lakshraj@gmail.com\n\n"
            "TECHNICAL SKILLS\n"
            "Frontend: React.js, HTML5, CSS3, JavaScript (ES6+), Tailwind CSS, Recharts\n"
            "Backend: Node.js, Express.js, FastAPI\n"
            "Databases: PostgreSQL, MongoDB, Redis\n"
            "Machine Learning: PyTorch, TensorFlow, Scikit-Learn, Pandas, NumPy, Keras\n"
            "Languages: Python, Java, JavaScript, SQL\n"
            "Tools: Git, GitHub, Docker, Vite\n\n"
            "PROJECTS\n"
            "SmartHealth: MERN & AI Diagnostic Platform\n"
            "Built React.js frontend, Express backend, FastAPI for PyTorch ResNet-50 models.\n"
            "Predictify: Sales Forecasting Dashboard\n"
            "Implemented React charts, trained LSTM neural networks in TensorFlow, Express APIs."
        )
        
        job_description = (
            "We are looking for a Software Engineer with expertise in MERN stack web development "
            "and Machine Learning. Must have experience with React.js, Node.js, Express, MongoDB, "
            "and Python (PyTorch or TensorFlow). You will build full-stack interfaces and integrate "
            "deep learning models."
        )
        
        target_role = "Software Engineer"
        
        # Phase 1: Orchestrate
        payload = {
            "resume_text": resume_text,
            "job_description": job_description,
            "target_role": target_role,
            "github_username": None
        }
        
        print("Sending Phase 1 request...")
        res = requests.post(f"{BASE_URL}/api/orchestrate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        
        self.assertEqual(data["status"], "PENDING_HITL")
        session_id = data["session_id"]
        self.assertIsNotNone(session_id)
        
        resume_analysis = data["resume_analysis"]
        self.assertIn("extracted_skills", resume_analysis)
        self.assertIn("ats_score", resume_analysis)
        
        # Phase 2: Approve
        approve_payload = {
            "session_id": session_id,
            "approved": True
        }
        
        print("Sending Phase 2 approval request...")
        approve_res = requests.post(f"{BASE_URL}/api/hitl-approve", json=approve_payload)
        self.assertEqual(approve_res.status_code, 200)
        final_data = approve_res.json()
        
        self.assertEqual(final_data["status"], "COMPLETED")
        results = final_data["results"]
        
        # Verify Model 2: Job Matcher
        job_match = results["job_match"]
        self.assertIsNotNone(job_match)
        self.assertIn("match_percentage", job_match)
        print(f"Sample A Job Match: {job_match['match_percentage']}%")
        self.assertGreaterEqual(job_match["match_percentage"], 70)
        
        # Verify Model 3: Interview Coach
        interview_prep = results["interview_prep"]
        self.assertIsNotNone(interview_prep)
        
        tech_qs = interview_prep.get("technical_questions", [])
        hr_qs = interview_prep.get("hr_questions", [])
        study_plan = interview_prep.get("study_plan", [])
        
        print(f"Sample A Technical Questions Count: {len(tech_qs)}")
        print(f"Sample A HR Questions Count: {len(hr_qs)}")
        
        self.assertGreaterEqual(len(tech_qs), 10, "Technical questions should be at least 10")
        self.assertGreaterEqual(len(hr_qs), 5, "HR questions should be at least 5")
        self.assertGreaterEqual(len(study_plan), 5, "Study plan should cover at least 5 days")

    def test_sample_b_mechanical_engineer(self):
        print("\n--- Running Sample B (Mechanical Design Engineer) ---")
        
        resume_text = (
            "VIVEK MEHTA\n"
            "Mechanical Design & CAD Engineer\n"
            "vivek.mehta@gmail.com\n\n"
            "TECHNICAL SKILLS\n"
            "CAD/CAE Tools: AutoCAD, SolidWorks, CATIA, Autodesk Inventor, ANSYS (FEA)\n"
            "Core Knowledge: Thermodynamics, Fluid Mechanics, Material Science, Machine Design\n"
            "Manufacturing: CNC Programming, GD&T, DFM, Prototyping\n"
            "Analysis: Static structural analysis, Thermal analysis, CFD\n\n"
            "PROJECTS\n"
            "High-Pressure Valve Design\n"
            "Designed Valve Body in SolidWorks. Performed structural static analysis using ANSYS FEA to withstand 150 bar.\n"
            "HVAC Piping System Layout\n"
            "Created layouts and HVAC design flowsheets in AutoCAD for a commercial shopping complex project."
        )
        
        job_description = (
            "We are seeking a Mechanical Design Engineer. Responsibilities include creating 3D CAD models, "
            "designing physical components, and conducting Finite Element Analysis (FEA). "
            "Proficiency in SolidWorks and AutoCAD is required. Experience with ANSYS is highly preferred."
        )
        
        target_role = "Mechanical Design Engineer"
        
        # Phase 1: Orchestrate
        payload = {
            "resume_text": resume_text,
            "job_description": job_description,
            "target_role": target_role,
            "github_username": None
        }
        
        print("Sending Phase 1 request...")
        res = requests.post(f"{BASE_URL}/api/orchestrate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        
        self.assertEqual(data["status"], "PENDING_HITL")
        session_id = data["session_id"]
        
        # Phase 2: Approve
        approve_payload = {
            "session_id": session_id,
            "approved": True
        }
        
        print("Sending Phase 2 approval request...")
        approve_res = requests.post(f"{BASE_URL}/api/hitl-approve", json=approve_payload)
        self.assertEqual(approve_res.status_code, 200)
        final_data = approve_res.json()
        
        self.assertEqual(final_data["status"], "COMPLETED")
        results = final_data["results"]
        
        # Verify Model 2: Job Matcher
        job_match = results["job_match"]
        self.assertIsNotNone(job_match)
        self.assertIn("match_percentage", job_match)
        print(f"Sample B Job Match: {job_match['match_percentage']}%")
        self.assertGreaterEqual(job_match["match_percentage"], 70)
        
        # Verify Model 3: Interview Coach
        interview_prep = results["interview_prep"]
        self.assertIsNotNone(interview_prep)
        
        tech_qs = interview_prep.get("technical_questions", [])
        hr_qs = interview_prep.get("hr_questions", [])
        
        print(f"Sample B Technical Questions Count: {len(tech_qs)}")
        print(f"Sample B HR Questions Count: {len(hr_qs)}")
        
        self.assertGreaterEqual(len(tech_qs), 10, "Technical questions should be at least 10")
        self.assertGreaterEqual(len(hr_qs), 5, "HR questions should be at least 5")

    def test_sample_cross_match_mismatched_domains(self):
        print("\n--- Running Cross-Match Scenario (Software Engineer vs. Mechanical Job Description) ---")
        
        software_resume_text = (
            "LAKSH RAJ\n"
            "Full Stack & Machine Learning Engineer\n"
            "aec.it.lakshraj@gmail.com\n\n"
            "TECHNICAL SKILLS\n"
            "Frontend: React.js, HTML5, CSS3, JavaScript (ES6+), Tailwind CSS, Recharts\n"
            "Backend: Node.js, Express.js, FastAPI\n"
            "Databases: PostgreSQL, MongoDB, Redis\n"
            "Machine Learning: PyTorch, TensorFlow, Scikit-Learn\n"
            "Languages: Python, Java, JavaScript, SQL\n"
            "Tools: Git, GitHub, Docker, Vite"
        )
        
        mechanical_job_description = (
            "We are seeking a Mechanical Design Engineer. Responsibilities include creating 3D CAD models, "
            "designing physical components, and conducting Finite Element Analysis (FEA). "
            "Proficiency in SolidWorks and AutoCAD is required. Experience with ANSYS is highly preferred."
        )
        
        target_role = "Mechanical Design Engineer"
        
        payload = {
            "resume_text": software_resume_text,
            "job_description": mechanical_job_description,
            "target_role": target_role,
            "github_username": None
        }
        
        print("Sending Phase 1 request for mismatched profile...")
        res = requests.post(f"{BASE_URL}/api/orchestrate", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        
        session_id = data["session_id"]
        
        approve_payload = {
            "session_id": session_id,
            "approved": True
        }
        
        print("Sending Phase 2 approval request for mismatched profile...")
        approve_res = requests.post(f"{BASE_URL}/api/hitl-approve", json=approve_payload)
        self.assertEqual(approve_res.status_code, 200)
        final_data = approve_res.json()
        
        results = final_data["results"]
        job_match = results["job_match"]
        
        print(f"Mismatched Domains Job Match: {job_match['match_percentage']}%")
        # Domain fit is 30% weight, skill overlap is 40% weight.
        # Since it's a completely different domain (SW vs Mech), the overall match percentage must be low (< 35%)
        self.assertLess(job_match["match_percentage"], 35, "Cross-matched score should be low (<35%) for different domains")
        print("Mismatched domain check passed successfully!")

if __name__ == "__main__":
    unittest.main()
