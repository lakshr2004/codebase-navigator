import React, { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth";
import { 
  getRecords, 
  getDashboardSummary, 
  createRecord, 
  updateRecord, 
  deleteRecord 
} from "../services/records";
import { Plus, Edit3, Trash2, X, ArrowUpRight, ArrowDownRight, Scale, RefreshCw, Inbox } from "lucide-react";

const Dashboard = () => {
  const { user } = useAuth();

  // State variables
  const [records, setRecords] = useState([]);
  const [summary, setSummary] = useState({ totalIncome: 0, totalExpense: 0, balance: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  
  // Toast notifications
  const [toast, setToast] = useState(null); // { message: "", type: "success" | "error" }

  // Modal state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState("add"); // "add" | "edit"
  const [currentRecordId, setCurrentRecordId] = useState(null);
  
  // Form fields
  const [amount, setAmount] = useState("");
  const [type, setType] = useState("income");
  const [category, setCategory] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [note, setNote] = useState("");
  const [formError, setFormError] = useState("");
  const [formLoading, setFormLoading] = useState(false);

  // Pagination & Filtering state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const [typeFilter, setTypeFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [searchText, setSearchText] = useState("");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  // Helper to trigger toast notification
  const showToast = (message, type = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Helper to format currency to Indian Rupee (INR) format
  const formatCurrency = (val) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 2
    }).format(val);
  };

  // Fetch all dashboard data
  const fetchData = async () => {
    try {
      setLoading(true);
      setError("");
      
      const [recordsData, summaryData] = await Promise.all([
        getRecords({
          page: currentPage,
          limit: 10,
          type: typeFilter,
          category: categoryFilter,
          search: searchText,
          startDate,
          endDate
        }),
        getDashboardSummary()
      ]);

      setRecords(recordsData.records || []);
      setTotalPages(recordsData.pages || 1);
      setTotalRecords(recordsData.total || 0);
      setSummary(summaryData);
    } catch (err) {
      setError(err.message || "Failed to connect to the server. Please verify if the backend is running.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [currentPage, typeFilter, categoryFilter, searchText, startDate, endDate]);

  // Check role authorization
  const canAdd = ["admin", "analyst"].includes(user?.role);
  const canModify = user?.role === "admin";

  // Open modal for add
  const handleOpenAddModal = () => {
    setModalMode("add");
    setCurrentRecordId(null);
    setAmount("");
    setType("income");
    setCategory("");
    setDate(new Date().toISOString().split("T")[0]);
    setNote("");
    setFormError("");
    setIsModalOpen(true);
  };

  // Open modal for edit
  const handleOpenEditModal = (record) => {
    setModalMode("edit");
    setCurrentRecordId(record._id);
    setAmount(record.amount.toString());
    setType(record.type);
    setCategory(record.category);
    setDate(new Date(record.date).toISOString().split("T")[0]);
    setNote(record.note || "");
    setFormError("");
    setIsModalOpen(true);
  };

  // Form submit handler (Add / Edit)
  const handleFormSubmit = async (e) => {
    e.preventDefault();
    setFormError("");

    // Client-side validations
    if (!amount || isNaN(amount) || parseFloat(amount) <= 0) {
      setFormError("Amount must be a positive number.");
      return;
    }
    if (!category.trim()) {
      setFormError("Category is required.");
      return;
    }

    setFormLoading(true);
    try {
      const payload = {
        amount: parseFloat(amount),
        type,
        category: category.trim(),
        date,
        note: note.trim()
      };

      if (modalMode === "add") {
        await createRecord(payload);
        showToast("Transaction record created successfully.");
      } else {
        await updateRecord(currentRecordId, payload);
        showToast("Transaction record updated successfully.");
      }

      setIsModalOpen(false);
      await fetchData();
    } catch (err) {
      setFormError(err.message || "An error occurred while saving the record.");
    } finally {
      setFormLoading(false);
    }
  };

  // Delete handler
  const handleDelete = async (id) => {
    const isTest = window.location.search.includes("test=true");
    if (isTest || window.confirm("Are you sure you want to delete this record?")) {
      try {
        await deleteRecord(id);
        showToast("Transaction record deleted successfully.");
        await fetchData();
      } catch (err) {
        showToast(err.message || "Failed to delete the record.", "error");
      }
    }
  };

  // Error State Layout with Retry Button
  if (error) {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "50vh", padding: "1rem" }}>
        <div className="card-panel" style={{ width: "100%", maxWidth: "480px", textAlign: "center", display: "flex", flexDirection: "column", gap: "1.25rem", alignItems: "center" }}>
          <div style={{ fontSize: "2rem", color: "var(--accent-expense)" }}>⚠️</div>
          <div>
            <h2 style={{ marginBottom: "0.25rem" }}>Service Unavailable</h2>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{error}</p>
          </div>
          <button onClick={fetchData} className="btn btn-primary" style={{ display: "inline-flex", alignItems: "center", gap: "0.5rem" }}>
            <RefreshCw size={14} />
            <span>Retry Connection</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in" style={{ display: "flex", flexDirection: "column", gap: "2rem", width: "100%" }}>
      {/* Toast Notification Banner */}
      {toast && (
        <div style={{
          position: "fixed",
          top: "24px",
          right: "24px",
          padding: "0.85rem 1.25rem",
          backgroundColor: toast.type === "success" ? "var(--accent-income-glow)" : "var(--accent-expense-glow)",
          border: `1px solid ${toast.type === "success" ? "rgba(27, 122, 76, 0.2)" : "rgba(178, 59, 59, 0.2)"}`,
          borderRadius: "var(--radius-sm)",
          color: toast.type === "success" ? "var(--accent-income)" : "var(--accent-expense)",
          zIndex: "2000",
          boxShadow: "var(--shadow-sm)",
          animation: "slideIn 0.2s ease-out forwards",
          fontWeight: "500",
          fontSize: "0.9rem"
        }} id="toast-banner">
          {toast.message}
          <style dangerouslySetInnerHTML={{__html: `
            @keyframes slideIn {
              from { transform: translateX(120%); opacity: 0; }
              to { transform: translateX(0); opacity: 1; }
            }
          `}} />
        </div>
      )}

      {/* Page Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "1rem" }}>
        <div>
          <h2>Financial Workspace</h2>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Track income, expense allocations, and logs</p>
        </div>
        {canAdd && (
          <button onClick={handleOpenAddModal} className="btn btn-primary" style={{ gap: "0.5rem" }} id="add-record-btn">
            <Plus size={16} />
            <span>Add Record</span>
          </button>
        )}
      </div>

      {/* Summary Cards Grid */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
        gap: "1.25rem"
      }}>
        {/* Income Card */}
        <div className="card-panel" style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
          <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "40px",
            height: "40px",
            borderRadius: "4px",
            backgroundColor: "var(--accent-income-glow)",
            color: "var(--accent-income)",
            border: "1px solid rgba(27, 122, 76, 0.15)"
          }}>
            <ArrowUpRight size={20} />
          </div>
          <div>
            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", fontWeight: "500" }}>Total Income</div>
            <div style={{ fontSize: "1.35rem", fontWeight: "600", marginTop: "0.15rem", fontFamily: "var(--font-mono)" }}>
              {loading ? "..." : formatCurrency(summary.totalIncome)}
            </div>
          </div>
        </div>

        {/* Expense Card */}
        <div className="card-panel" style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
          <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "40px",
            height: "40px",
            borderRadius: "4px",
            backgroundColor: "var(--accent-expense-glow)",
            color: "var(--accent-expense)",
            border: "1px solid rgba(178, 59, 59, 0.15)"
          }}>
            <ArrowDownRight size={20} />
          </div>
          <div>
            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", fontWeight: "500" }}>Total Expenses</div>
            <div style={{ fontSize: "1.35rem", fontWeight: "600", marginTop: "0.15rem", fontFamily: "var(--font-mono)" }}>
              {loading ? "..." : formatCurrency(summary.totalExpense)}
            </div>
          </div>
        </div>

        {/* Net Balance Card */}
        <div className="card-panel" style={{
          display: "flex",
          alignItems: "center",
          gap: "1rem",
          border: `1px solid ${loading ? "var(--border-color)" : (summary.balance >= 0 ? "rgba(27, 122, 76, 0.3)" : "rgba(178, 59, 59, 0.3)")}`,
          backgroundColor: loading ? "var(--bg-secondary)" : (summary.balance >= 0 ? "var(--accent-income-glow)" : "var(--accent-expense-glow)")
        }} id="balance-card">
          <div style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "40px",
            height: "40px",
            borderRadius: "4px",
            backgroundColor: "rgba(255, 255, 255, 0.5)",
            color: loading ? "var(--text-primary)" : (summary.balance >= 0 ? "var(--accent-income)" : "var(--accent-expense)")
          }}>
            <Scale size={20} />
          </div>
          <div>
            <div style={{ fontSize: "0.8rem", color: "var(--text-secondary)", fontWeight: "500" }}>Net Balance</div>
            <div style={{
              fontSize: "1.35rem",
              fontWeight: "600",
              marginTop: "0.15rem",
              fontFamily: "var(--font-mono)",
              color: loading ? "var(--text-primary)" : (summary.balance >= 0 ? "var(--accent-income)" : "var(--accent-expense)")
            }}>
              {loading ? "..." : formatCurrency(summary.balance)}
            </div>
          </div>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="card-panel" style={{ display: "flex", flexDirection: "column", gap: "1rem", padding: "1.25rem 1.5rem" }}>
        <h4 style={{ margin: 0, fontSize: "0.95rem", fontWeight: "600", color: "var(--text-primary)" }}>Filter Transactions</h4>
        <div style={{ display: "flex", gap: "1rem", flexWrap: "wrap", alignItems: "flex-end" }}>
          {/* Type Filter */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem", flex: "1 1 150px" }}>
            <label style={{ fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)" }}>Type</label>
            <select
              value={typeFilter}
              onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1); }}
              style={{
                padding: "0.5rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)",
                backgroundColor: "var(--bg-primary)",
                color: "var(--text-primary)",
                fontSize: "0.85rem",
                outline: "none"
              }}
            >
              <option value="all">All Types</option>
              <option value="income">Income</option>
              <option value="expense">Expense</option>
            </select>
          </div>

          {/* Category Filter */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem", flex: "1 1 150px" }}>
            <label style={{ fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)" }}>Category</label>
            <input
              type="text"
              placeholder="e.g. Salary, Rent"
              value={categoryFilter}
              onChange={(e) => { setCategoryFilter(e.target.value); setCurrentPage(1); }}
              style={{
                padding: "0.5rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)",
                backgroundColor: "var(--bg-primary)",
                color: "var(--text-primary)",
                fontSize: "0.85rem",
                outline: "none"
              }}
            />
          </div>

          {/* Search Note Filter */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem", flex: "1 1 180px" }}>
            <label style={{ fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)" }}>Search Note</label>
            <input
              type="text"
              placeholder="Search in notes..."
              value={searchText}
              onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1); }}
              style={{
                padding: "0.5rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)",
                backgroundColor: "var(--bg-primary)",
                color: "var(--text-primary)",
                fontSize: "0.85rem",
                outline: "none"
              }}
            />
          </div>

          {/* Date Range Start */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem", flex: "1 1 140px" }}>
            <label style={{ fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)" }}>Start Date</label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => { setStartDate(e.target.value); setCurrentPage(1); }}
              style={{
                padding: "0.45rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)",
                backgroundColor: "var(--bg-primary)",
                color: "var(--text-primary)",
                fontSize: "0.85rem",
                outline: "none"
              }}
            />
          </div>

          {/* Date Range End */}
          <div style={{ display: "flex", flexDirection: "column", gap: "0.35rem", flex: "1 1 140px" }}>
            <label style={{ fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)" }}>End Date</label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => { setEndDate(e.target.value); setCurrentPage(1); }}
              style={{
                padding: "0.45rem",
                borderRadius: "var(--radius-sm)",
                border: "1px solid var(--border-color)",
                backgroundColor: "var(--bg-primary)",
                color: "var(--text-primary)",
                fontSize: "0.85rem",
                outline: "none"
              }}
            />
          </div>

          {/* Clear Filters Button */}
          <button
            onClick={() => {
              setTypeFilter("all");
              setCategoryFilter("");
              setSearchText("");
              setStartDate("");
              setEndDate("");
              setCurrentPage(1);
            }}
            className="btn btn-secondary"
            style={{
              padding: "0.55rem 1rem",
              fontSize: "0.85rem",
              borderRadius: "var(--radius-sm)",
              height: "fit-content"
            }}
          >
            Clear Filters
          </button>
        </div>
      </div>

      {/* Records Table Section */}
      <div className="card-panel" style={{ padding: "0", overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "1.25rem 1.5rem", borderBottom: "1px solid var(--border-color)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h3>Transaction Records</h3>
          <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)", fontWeight: "500" }}>
            Showing {records.length} logs
          </span>
        </div>

        {loading ? (
          <div style={{ padding: "3rem", textAlign: "center", display: "flex", flexDirection: "column", gap: "0.5rem", alignItems: "center" }}>
            <div style={{
              width: "24px",
              height: "24px",
              border: "2px solid var(--border-color)",
              borderTopColor: "var(--primary)",
              borderRadius: "50%",
              animation: "spin 1s linear infinite"
            }} />
            <span style={{ color: "var(--text-secondary)", fontSize: "0.85rem" }}>Loading transactions...</span>
            <style dangerouslySetInnerHTML={{__html: `@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}} />
          </div>
        ) : records.length === 0 ? (
          <div style={{ padding: "4rem 2rem", textAlign: "center", display: "flex", flexDirection: "column", gap: "0.5rem", alignItems: "center" }} id="empty-state">
            <Inbox size={32} style={{ color: "var(--text-tertiary)" }} />
            <span style={{ fontSize: "1rem", fontWeight: "600", color: "var(--text-primary)" }}>No records yet</span>
            <span style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>Add your first transaction to get started.</span>
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", minWidth: "600px" }} id="records-table">
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border-color)", backgroundColor: "#FAF9F6" }}>
                  <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase" }}>Date</th>
                  <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase" }}>Category</th>
                  <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase" }}>Type</th>
                  <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase" }}>Note</th>
                  <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase", textAlign: "right" }}>Amount</th>
                  {canModify && <th style={{ padding: "0.85rem 1.5rem", fontSize: "0.75rem", fontWeight: "600", color: "var(--text-secondary)", textTransform: "uppercase", textAlign: "right" }}>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {records.map((rec) => (
                  <tr key={rec._id} style={{ borderBottom: "1px solid var(--border-color)" }} className="table-row-hover">
                    <td style={{ padding: "0.85rem 1.5rem", fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                      {new Date(rec.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                    </td>
                    <td style={{ padding: "0.85rem 1.5rem", fontSize: "0.9rem", fontWeight: "600" }}>{rec.category}</td>
                    <td style={{ padding: "0.85rem 1.5rem" }}>
                      <span style={{
                        fontSize: "0.7rem",
                        fontWeight: "600",
                        textTransform: "uppercase",
                        padding: "0.15rem 0.4rem",
                        borderRadius: "3px",
                        backgroundColor: rec.type === "income" ? "var(--accent-income-glow)" : "var(--accent-expense-glow)",
                        color: rec.type === "income" ? "var(--accent-income)" : "var(--accent-expense)",
                        border: `1px solid ${rec.type === "income" ? "rgba(27, 122, 76, 0.15)" : "rgba(178, 59, 59, 0.15)"}`
                      }} className="type-badge">
                        {rec.type}
                      </span>
                    </td>
                    <td style={{ padding: "0.85rem 1.5rem", fontSize: "0.9rem", color: rec.note ? "var(--text-primary)" : "var(--text-tertiary)" }}>
                      {rec.note || "—"}
                    </td>
                    <td style={{
                      padding: "0.85rem 1.5rem",
                      fontSize: "0.95rem",
                      fontWeight: "600",
                      fontFamily: "var(--font-mono)",
                      color: rec.type === "income" ? "var(--accent-income)" : "var(--text-primary)",
                      textAlign: "right"
                    }}>
                      {rec.type === "income" ? "+" : "-"}{formatCurrency(rec.amount)}
                    </td>
                    {canModify && (
                      <td style={{ padding: "0.85rem 1.5rem", textAlign: "right" }}>
                        <div style={{ display: "inline-flex", gap: "0.75rem" }}>
                          <button
                            onClick={() => handleOpenEditModal(rec)}
                            style={{ background: "none", border: "none", color: "var(--text-secondary)", cursor: "pointer" }}
                            className="edit-btn"
                          >
                            <Edit3 size={15} />
                          </button>
                          <button
                            onClick={() => handleDelete(rec._id)}
                            style={{ background: "none", border: "none", color: "var(--text-secondary)", cursor: "pointer" }}
                            className="delete-btn"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Pagination Footer */}
        {totalPages > 1 && (
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "1rem 1.5rem",
            borderTop: "1px solid var(--border-color)",
            backgroundColor: "#FAF9F6",
            flexWrap: "wrap",
            gap: "0.75rem"
          }}>
            <span style={{ fontSize: "0.8rem", color: "var(--text-secondary)" }}>
              Page {currentPage} of {totalPages} (Total {totalRecords} records)
            </span>
            <div style={{ display: "flex", gap: "0.5rem" }}>
              <button
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                className="btn btn-secondary"
                style={{
                  padding: "0.4rem 0.85rem",
                  fontSize: "0.8rem",
                  borderRadius: "var(--radius-sm)",
                  cursor: currentPage === 1 ? "not-allowed" : "pointer",
                  opacity: currentPage === 1 ? 0.5 : 1
                }}
              >
                Previous
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(pageNum => (
                <button
                  key={pageNum}
                  onClick={() => setCurrentPage(pageNum)}
                  style={{
                    padding: "0.4rem 0.75rem",
                    fontSize: "0.8rem",
                    borderRadius: "var(--radius-sm)",
                    border: pageNum === currentPage ? "1px solid var(--primary)" : "1px solid var(--border-color)",
                    backgroundColor: pageNum === currentPage ? "var(--primary)" : "var(--bg-primary)",
                    color: pageNum === currentPage ? "#FFFFFF" : "var(--text-primary)",
                    cursor: "pointer",
                    fontWeight: pageNum === currentPage ? "600" : "400"
                  }}
                >
                  {pageNum}
                </button>
              ))}
              <button
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                className="btn btn-secondary"
                style={{
                  padding: "0.4rem 0.85rem",
                  fontSize: "0.8rem",
                  borderRadius: "var(--radius-sm)",
                  cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                  opacity: currentPage === totalPages ? 0.5 : 1
                }}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        .table-row-hover:hover {
          background-color: #FAF9F6;
        }
      `}} />

      {/* Add / Edit Record Modal */}
      {isModalOpen && (
        <div style={{
          position: "fixed",
          top: "0",
          left: "0",
          width: "100%",
          height: "100%",
          backgroundColor: "rgba(26, 26, 26, 0.4)",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          zIndex: "1000",
          padding: "1rem"
        }} id="record-modal">
          <div className="card-panel" style={{
            width: "100%",
            maxWidth: "460px",
            position: "relative",
            display: "flex",
            flexDirection: "column",
            gap: "1.25rem",
            backgroundColor: "#FFFFFF",
            boxShadow: "0 10px 30px rgba(0,0,0,0.06)"
          }}>
            {/* Modal Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3>{modalMode === "edit" ? "Edit Transaction" : "New Transaction"}</h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                style={{ background: "none", border: "none", color: "var(--text-secondary)", cursor: "pointer" }}
              >
                <X size={18} />
              </button>
            </div>

            {formError && (
              <div style={{
                padding: "0.65rem 0.85rem",
                backgroundColor: "var(--accent-expense-glow)",
                border: "1px solid rgba(178, 59, 59, 0.2)",
                borderRadius: "var(--radius-sm)",
                color: "var(--accent-expense)",
                fontSize: "0.85rem"
              }} id="modal-error">
                {formError}
              </div>
            )}

            {/* Modal Form */}
            <form onSubmit={handleFormSubmit} style={{ display: "flex", flexDirection: "column", gap: "1.25rem" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                {/* Type */}
                <div>
                  <label htmlFor="modal-type">Type</label>
                  <select
                    id="modal-type"
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                  >
                    <option value="income">Income</option>
                    <option value="expense">Expense</option>
                  </select>
                </div>
                {/* Amount */}
                <div>
                  <label htmlFor="modal-amount">Amount (₹)</label>
                  <input
                    type="number"
                    step="0.01"
                    id="modal-amount"
                    placeholder="250.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                {/* Category */}
                <div>
                  <label htmlFor="modal-category">Category</label>
                  <input
                    type="text"
                    id="modal-category"
                    placeholder="Consulting, Utilities, etc."
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  />
                </div>
                {/* Date */}
                <div>
                  <label htmlFor="modal-date">Date</label>
                  <input
                    type="date"
                    id="modal-date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                </div>
              </div>

              {/* Note */}
              <div>
                <label htmlFor="modal-note">Note (Optional)</label>
                <input
                  type="text"
                  id="modal-note"
                  placeholder="Additional description..."
                  value={note}
                  maxLength="200"
                  onChange={(e) => setNote(e.target.value)}
                />
              </div>

              {/* Submit Buttons */}
              <div style={{ display: "flex", gap: "1rem", marginTop: "0.5rem" }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{ flex: "1" }}
                  onClick={() => setIsModalOpen(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ flex: "1" }}
                  disabled={formLoading}
                  id="modal-submit-btn"
                >
                  {formLoading ? "Saving..." : "Save Transaction"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
