const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const User = require("./models/User");

const BASE_URL = "http://localhost:5000";
const timestamp = Date.now();

const logBuffer = [];
function log(...args) {
  const line = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg).join(" ");
  console.log(line);
  logBuffer.push(line);
}

const users = {
  admin: {
    name: "Admin User",
    email: `admin_${timestamp}@test.com`,
    password: "password123",
    role: "admin" // Note: This will be ignored by registration and forced to viewer
  },
  analyst: {
    name: "Analyst User",
    email: `analyst_${timestamp}@test.com`,
    password: "password123",
    role: "analyst" // Note: This will be ignored by registration and forced to viewer
  },
  viewer: {
    name: "Viewer User",
    email: `viewer_${timestamp}@test.com`,
    password: "password123",
    role: "viewer"
  }
};

const tokens = {
  admin: null,
  analyst: null,
  viewer: null
};

const userDetails = {
  admin: null,
  analyst: null,
  viewer: null
};

// Helper for HTTP requests
async function request(pathStr, method = "GET", body = null, token = null, origin = null) {
  const url = `${BASE_URL}${pathStr}`;
  const headers = {
    "Content-Type": "application/json"
  };
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  if (origin) {
    headers["Origin"] = origin;
  }

  const options = {
    method,
    headers
  };
  if (body) {
    options.body = JSON.stringify(body);
  }

  log(`\n>>> REQUEST: ${method} ${pathStr}`);
  if (body) log("Request Body:", body);
  if (headers["Authorization"]) log("Auth Header:", headers["Authorization"].substring(0, 30) + "...");
  if (origin) log("Origin Header:", origin);

  try {
    const res = await fetch(url, options);
    const contentType = res.headers.get("content-type");
    let responseData;
    if (contentType && contentType.includes("application/json")) {
      responseData = await res.json();
    } else {
      responseData = await res.text();
    }

    log(`<<< RESPONSE [Status ${res.status}]`);
    log("Headers:", Object.fromEntries(res.headers.entries()));
    log("Body:", responseData);
    return { status: res.status, headers: res.headers, body: responseData };
  } catch (err) {
    log(`<<< ERROR:`, err.message);
    return { error: err.message };
  }
}

async function runTests() {
  log("--- PHASE 2 (UPDATED): LOCAL TESTING ---");

  // ==========================================
  // CORS TEST
  // ==========================================
  log("\n=== TESTING CORS ===");
  await request("/", "GET", null, null, "http://localhost:3000");

  // ==========================================
  // 1. REGISTER USERS (Verify role in response is "viewer" for all)
  // ==========================================
  log("\n=== 1. REGISTERING USERS (ROLE IN BODY SHOULD BE IGNORED) ===");
  for (const key of Object.keys(users)) {
    const res = await request("/api/auth/register", "POST", users[key]);
    if (res.status === 201) {
      userDetails[key] = res.body.user;
      log(`Registered user [${key}] role returned by server: ${res.body.user.role}`);
    }
  }

  // ==========================================
  // 1.5 DIRECT DATABASE ACCESS TO SEED ADMIN & ANALYST
  // ==========================================
  log("\n=== 1.5 UPDATING ROLES DIRECTLY IN MONGO DB TO BOOTSTRAP ===");
  try {
    // Load config from environment or default to local mongodb uri
    const mongoUri = process.env.MONGO_URI || "mongodb://localhost:27017/financeDB";
    await mongoose.connect(mongoUri);
    log("Connected to MongoDB for role seeding...");

    // Set the actual roles for admin and analyst in the database
    if (userDetails.admin) {
      await User.findByIdAndUpdate(userDetails.admin.id, { role: "admin" });
      log(`Bootstrapped admin database role to: admin`);
    }
    if (userDetails.analyst) {
      await User.findByIdAndUpdate(userDetails.analyst.id, { role: "analyst" });
      log(`Bootstrapped analyst database role to: analyst`);
    }

    await mongoose.disconnect();
    log("Disconnected from MongoDB.");
  } catch (err) {
    log("Failed to seed database roles:", err.message);
    process.exit(1);
  }

  // ==========================================
  // 2. LOGIN USERS
  // ==========================================
  log("\n=== 2. LOGGING IN (VERIFYING UPDATED ROLES) ===");
  for (const key of Object.keys(users)) {
    const res = await request("/api/auth/login", "POST", {
      email: users[key].email,
      password: users[key].password
    });
    if (res.status === 200) {
      tokens[key] = res.body.token;
      log(`Logged in as [${key}]. Role: ${res.body.user.role}`);
    }
  }

  // ==========================================
  // 2.5 TESTING ADMIN-ONLY ROLE UPDATE ROUTE
  // ==========================================
  log("\n=== 2.5 TESTING ADMIN-ONLY ROLE UPDATE ROUTE ===");
  if (userDetails.viewer && tokens.admin && tokens.analyst) {
    const viewerId = userDetails.viewer.id;

    // A. Analyst attempts to change role of viewer (Should fail 403)
    log("\n--- A. Analyst attempts to change Viewer role to admin ---");
    await request(`/api/auth/users/${viewerId}/role`, "PUT", { role: "admin" }, tokens.analyst);

    // B. Admin attempts to change role to invalid role (Should fail 400 Validation)
    log("\n--- B. Admin attempts to change role to invalid role ---");
    await request(`/api/auth/users/${viewerId}/role`, "PUT", { role: "superadmin" }, tokens.admin);

    // C. Admin changes role to analyst (Should succeed 200)
    log("\n--- C. Admin changes Viewer role to analyst ---");
    await request(`/api/auth/users/${viewerId}/role`, "PUT", { role: "analyst" }, tokens.admin);

    // D. Admin changes role back to viewer (Should succeed 200)
    log("\n--- D. Admin changes role back to viewer ---");
    await request(`/api/auth/users/${viewerId}/role`, "PUT", { role: "viewer" }, tokens.admin);
  }

  // ==========================================
  // 3. ROLE-BASED ACCESS CONTROL TESTS
  // ==========================================
  log("\n=== 3. TESTING ROLE-BASED ROUTE ACCESS ===");
  
  // Test /api/admin
  log("\n--- Testing Admin Route (/api/admin) ---");
  await request("/api/admin", "GET", null, tokens.admin);
  await request("/api/admin", "GET", null, tokens.analyst);
  await request("/api/admin", "GET", null, tokens.viewer);

  // Test /api/analysis
  log("\n--- Testing Analysis Route (/api/analysis) ---");
  await request("/api/analysis", "GET", null, tokens.admin);
  await request("/api/analysis", "GET", null, tokens.analyst);
  await request("/api/analysis", "GET", null, tokens.viewer);

  // Test /api/protected
  log("\n--- Testing Protected Route (/api/protected) ---");
  await request("/api/protected", "GET", null, tokens.viewer);

  // ==========================================
  // 4. CREATE RECORDS (Viewers should be blocked now)
  // ==========================================
  log("\n=== 4. CREATING FINANCIAL RECORDS ===");
  
  const recordsCreated = {
    admin: null,
    analyst: null
  };

  const sampleRecord = (role) => ({
    amount: 1500,
    type: "income",
    category: "Consulting",
    note: `Created by ${role}`
  });

  // Admin creates record (Should succeed)
  log("\n--- Admin creates record ---");
  let resAdminRec = await request("/api/records", "POST", sampleRecord("admin"), tokens.admin);
  if (resAdminRec.status === 201) recordsCreated.admin = resAdminRec.body.record;

  // Analyst creates record (Should succeed)
  log("\n--- Analyst creates record ---");
  let resAnalystRec = await request("/api/records", "POST", sampleRecord("analyst"), tokens.analyst);
  if (resAnalystRec.status === 201) recordsCreated.analyst = resAnalystRec.body.record;

  // Viewer creates record (Should now FAIL 403 Forbidden)
  log("\n--- Viewer attempts to create record (Should fail 403) ---");
  await request("/api/records", "POST", sampleRecord("viewer"), tokens.viewer);

  // ==========================================
  // 5. GET RECORDS & SUMMARY
  // ==========================================
  log("\n=== 5. GETTING RECORDS AND SUMMARY ===");
  
  log("\n--- Admin Records & Summary ---");
  await request("/api/records", "GET", null, tokens.admin);
  await request("/api/records/summary", "GET", null, tokens.admin);

  log("\n--- Analyst Records & Summary ---");
  await request("/api/records", "GET", null, tokens.analyst);
  await request("/api/records/summary", "GET", null, tokens.analyst);

  log("\n--- Viewer Records & Summary ---");
  await request("/api/records", "GET", null, tokens.viewer);
  await request("/api/records/summary", "GET", null, tokens.viewer);

  // ==========================================
  // 6. UPDATE RECORD (Admin Only)
  // ==========================================
  log("\n=== 6. UPDATING RECORDS (Admin Only Route) ===");
  
  if (recordsCreated.admin) {
    const adminRecId = recordsCreated.admin._id;
    const updateBody = { amount: 2000, note: "Updated by admin" };

    // Admin updates own record (Should succeed)
    log("\n--- Admin updates own record ---");
    await request(`/api/records/${adminRecId}`, "PUT", updateBody, tokens.admin);

    // Analyst updates admin's record (Should be blocked by role)
    log("\n--- Analyst attempts to update record ---");
    await request(`/api/records/${adminRecId}`, "PUT", updateBody, tokens.analyst);

    // Viewer updates admin's record (Should be blocked by role)
    log("\n--- Viewer attempts to update record ---");
    await request(`/api/records/${adminRecId}`, "PUT", updateBody, tokens.viewer);
  }

  // Admin trying to update record of Analyst (Blocked by ownership check)
  if (recordsCreated.analyst && recordsCreated.admin) {
    const analystRecId = recordsCreated.analyst._id;
    const updateBody = { amount: 2500, note: "Admin trying to update analyst record" };
    log("\n--- Admin attempts to update Analyst's record ---");
    await request(`/api/records/${analystRecId}`, "PUT", updateBody, tokens.admin);
  }

  // ==========================================
  // 7. DELETE RECORD (Admin Only)
  // ==========================================
  log("\n=== 7. DELETING RECORDS (Admin Only Route) ===");
  
  if (recordsCreated.admin && recordsCreated.analyst) {
    const adminRecId = recordsCreated.admin._id;
    const analystRecId = recordsCreated.analyst._id;

    // Analyst attempts to delete admin's record (Blocked by role)
    log("\n--- Analyst attempts to delete Admin's record ---");
    await request(`/api/records/${adminRecId}`, "DELETE", null, tokens.analyst);

    // Admin attempts to delete Analyst's record (Blocked by user ownership check)
    log("\n--- Admin attempts to delete Analyst's record ---");
    await request(`/api/records/${analystRecId}`, "DELETE", null, tokens.admin);

    // Admin deletes own record (Should succeed)
    log("\n--- Admin deletes own record ---");
    await request(`/api/records/${adminRecId}`, "DELETE", null, tokens.admin);
  }

  // ==========================================
  // 8. ERROR HANDLING VALIDATION (ValidationError/CastError)
  // ==========================================
  log("\n=== 8. ERROR HANDLING VALIDATION (CastError / ValidationError) ===");
  if (tokens.admin && recordsCreated.admin) {
    // A. Invalid Mongoose ObjectId format (Should fail 404, not 500)
    log("\n--- A. Requesting record with invalid ObjectId length (CastError) ---");
    await request("/api/records/invalid_id_format_xyz", "PUT", { amount: 100 }, tokens.admin);

    // B. Mongoose Validation Error - Negative Amount (Should fail 400, not 500)
    log("\n--- B. Creating record with negative amount (ValidationError) ---");
    await request("/api/records", "POST", { amount: -500, type: "income", category: "Invalid" }, tokens.admin);
  }

  // Write all logs to a UTF-8 file
  const outputPath = path.join(__dirname, "test_output_utf8.txt");
  fs.writeFileSync(outputPath, logBuffer.join("\n"), "utf8");
  console.log(`\nWritten full test log to ${outputPath}`);
}

// Set env variable just in case
process.env.MONGO_URI = "mongodb://localhost:27017/financeDB";
runTests();
