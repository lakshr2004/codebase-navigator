import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { BrowserRouter } from "react-router-dom";
import Register from "../pages/Register";
import "@testing-library/jest-dom";

// Mock useAuth
const mockRegister = vi.fn();
vi.mock("../hooks/useAuth", () => ({
  useAuth: () => ({
    register: mockRegister,
  }),
}));

const renderRegister = () => {
  return render(
    <BrowserRouter>
      <Register />
    </BrowserRouter>
  );
};

describe("Register Page Component Tests", () => {
  beforeEach(() => {
    mockRegister.mockReset();
  });

  it("renders correctly with heading and form elements", () => {
    renderRegister();

    expect(screen.getByRole("heading", { name: /create account/i })).toBeInTheDocument();
    expect(screen.getByLabelText(/full name/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /register/i })).toBeInTheDocument();
  });

  it("shows error message when form is submitted empty", async () => {
    renderRegister();

    const registerBtn = screen.getByRole("button", { name: /register/i });
    fireEvent.click(registerBtn);

    expect(await screen.findByText(/please fill in all fields/i)).toBeInTheDocument();
  });

  it("shows error message when name is too short", async () => {
    renderRegister();

    fireEvent.change(screen.getByLabelText(/full name/i), { target: { value: "A" } });
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "valid@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });

    const registerBtn = screen.getByRole("button", { name: /register/i });
    fireEvent.click(registerBtn);

    expect(await screen.findByText(/name must be at least 2 characters long/i)).toBeInTheDocument();
  });

  it("shows error message when email is invalid", async () => {
    renderRegister();

    fireEvent.change(screen.getByLabelText(/full name/i), { target: { value: "John Doe" } });
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "invalidemail@domain" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });

    const registerBtn = screen.getByRole("button", { name: /register/i });
    fireEvent.click(registerBtn);

    expect(await screen.findByText(/please enter a valid email address/i)).toBeInTheDocument();
  });

  it("shows error message when password is too short", async () => {
    renderRegister();

    fireEvent.change(screen.getByLabelText(/full name/i), { target: { value: "John Doe" } });
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "valid@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "123" } });

    const registerBtn = screen.getByRole("button", { name: /register/i });
    fireEvent.click(registerBtn);

    expect(await screen.findByText(/password must be at least 6 characters long/i)).toBeInTheDocument();
  });

  it("calls register function and shows success message on success", async () => {
    mockRegister.mockResolvedValue({ success: true });
    renderRegister();

    fireEvent.change(screen.getByLabelText(/full name/i), { target: { value: "John Doe" } });
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "valid@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });

    const registerBtn = screen.getByRole("button", { name: /register/i });
    fireEvent.click(registerBtn);

    expect(mockRegister).toHaveBeenCalledWith("John Doe", "valid@test.com", "password123");
    expect(await screen.findByText(/registration successful/i)).toBeInTheDocument();
  });
});
