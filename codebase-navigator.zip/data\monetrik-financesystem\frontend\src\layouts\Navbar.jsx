import React from "react";
import { Link, NavLink } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

const Navbar = () => {
  const { user, logout } = useAuth();

  if (!user) return null;

  const showAnalysis = ["admin", "analyst"].includes(user.role);

  // Styling helpers for active navigation link
  const getNavLinkStyle = ({ isActive }) => ({
    padding: "0.4rem 0.85rem",
    borderRadius: "var(--radius-sm)",
    color: isActive ? "var(--text-primary)" : "var(--text-secondary)",
    backgroundColor: isActive ? "var(--bg-primary)" : "transparent",
    border: isActive ? "1px solid var(--border-color)" : "1px solid transparent",
    fontWeight: isActive ? "600" : "500",
    fontSize: "0.9rem",
    transition: "all var(--transition-fast)"
  });

  return (
    <nav style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "0.85rem 2rem",
      backgroundColor: "var(--bg-secondary)",
      borderBottom: "1px solid var(--border-color)",
      boxShadow: "var(--shadow-sm)"
    }}>
      {/* Brand logo */}
      <Link to="/dashboard" style={{ display: "flex", alignItems: "center", gap: "0.5rem", fontSize: "1.1rem", fontWeight: "700", color: "var(--text-primary)", textDecoration: "none" }}>
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--primary)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
          <path d="M12 2L2 7l10 5 10-5-10-5z" />
          <path d="M2 17l10 5 10-5" />
          <path d="M2 12l10 5 10-5" />
        </svg>
        <span>Monetrik-FinanceSystem</span>
      </Link>

      {/* Nav Links */}
      <div style={{ display: "flex", gap: "0.5rem" }}>
        <NavLink to="/dashboard" style={getNavLinkStyle}>
          Dashboard
        </NavLink>
        {showAnalysis && (
          <NavLink to="/analysis" style={getNavLinkStyle}>
            Analysis
          </NavLink>
        )}
      </div>

      {/* User Actions */}
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
          <span style={{ fontWeight: "600", fontSize: "0.9rem", color: "var(--text-primary)" }}>{user.name}</span>
          <span style={{
            fontSize: "0.7rem",
            fontWeight: "600",
            textTransform: "uppercase",
            letterSpacing: "0.03em",
            padding: "0.1rem 0.4rem",
            borderRadius: "4px",
            marginTop: "0.15rem",
            backgroundColor: user.role === "admin" 
              ? "#E8EEF5" 
              : user.role === "analyst"
              ? "var(--accent-income-glow)"
              : "#F0F0EE",
            color: user.role === "admin" 
              ? "var(--primary)" 
              : user.role === "analyst"
              ? "var(--accent-income)"
              : "var(--text-secondary)",
            border: `1px solid ${
              user.role === "admin" 
                ? "rgba(30, 58, 95, 0.2)" 
                : user.role === "analyst"
                ? "rgba(27, 122, 76, 0.2)"
                : "rgba(107, 107, 104, 0.2)"
            }`
          }}>
            {user.role}
          </span>
        </div>

        <button 
          onClick={logout} 
          className="btn btn-secondary" 
          style={{ 
            padding: "0.4rem 0.85rem", 
            fontSize: "0.85rem",
            borderColor: "var(--border-color)",
            color: "var(--text-primary)"
          }}
        >
          Logout
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
