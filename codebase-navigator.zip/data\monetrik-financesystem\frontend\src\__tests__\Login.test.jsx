import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { describe, it, expect, vi } from "vitest";
import { BrowserRouter } from "react-router-dom";
import Login from "../pages/Login";
import "@testing-library/jest-dom";

// Mock useAuth
const mockLogin = vi.fn();
vi.mock("../hooks/useAuth", () => ({
  useAuth: () => ({
    login: mockLogin,
  }),
}));

const renderLogin = () => {
  return render(
    <BrowserRouter>
      <Login />
    </BrowserRouter>
  );
};

describe("Login Page Component Tests", () => {
  beforeEach(() => {
    mockLogin.mockReset();
  });

  it("renders correctly with header and form elements", () => {
    renderLogin();
    
    expect(screen.getByRole("heading", { name: /sign in/i })).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/name@company.com/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/email address/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /sign in/i })).toBeInTheDocument();
  });

  it("shows error message when form is submitted empty", async () => {
    renderLogin();
    
    const submitBtn = screen.getByRole("button", { name: /sign in/i });
    fireEvent.click(submitBtn);
    
    expect(await screen.findByText(/please fill in all fields/i)).toBeInTheDocument();
  });

  it("shows error message when email is invalid", async () => {
    renderLogin();
    
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "invalidemail@domain" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });
    
    const submitBtn = screen.getByRole("button", { name: /sign in/i });
    fireEvent.click(submitBtn);
    
    expect(await screen.findByText(/please enter a valid email address/i)).toBeInTheDocument();
  });

  it("shows error message when password is too short", async () => {
    renderLogin();
    
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "valid@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "123" } });
    
    const submitBtn = screen.getByRole("button", { name: /sign in/i });
    fireEvent.click(submitBtn);
    
    expect(await screen.findByText(/password must be at least 6 characters long/i)).toBeInTheDocument();
  });

  it("calls login function and redirects on success", async () => {
    mockLogin.mockResolvedValue({ success: true });
    renderLogin();
    
    fireEvent.change(screen.getByLabelText(/email address/i), { target: { value: "valid@test.com" } });
    fireEvent.change(screen.getByLabelText(/password/i), { target: { value: "password123" } });
    
    const submitBtn = screen.getByRole("button", { name: /sign in/i });
    fireEvent.click(submitBtn);
    
    expect(mockLogin).toHaveBeenCalledWith("valid@test.com", "password123");
  });
});
